說明：
1.「SerailPinrtExample.ino」：為 Arduino C++ 程式原始碼，可以直接使用 Arduino IDE 開啟。
2.「SerailPinrtExample.xml」：為 BlocklyDuino 方塊程式原始碼，需要將檔案.xml檔放置【SerailPinrtExample資料夾】裡（沒有的話可以自行建立），就可以使用 BlocklyDuino 開啟資掉夾。